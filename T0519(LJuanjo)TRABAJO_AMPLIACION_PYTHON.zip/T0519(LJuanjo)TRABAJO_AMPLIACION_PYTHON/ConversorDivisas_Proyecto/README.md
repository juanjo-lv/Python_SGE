# Conversor de Divisas

## Descripcion

Conversor de divisas desarrollado en Python, con interfaz gráfica.
Con actualización de valores de divisas online (acceso a internet)

## Modulos Utilizados

    - TKInter interfaces gráficas.
    - Selenium para el driver de google chrome extracción de datos
    - ZipFile extracción del driver.
    - Time para los tiempos de espera
    