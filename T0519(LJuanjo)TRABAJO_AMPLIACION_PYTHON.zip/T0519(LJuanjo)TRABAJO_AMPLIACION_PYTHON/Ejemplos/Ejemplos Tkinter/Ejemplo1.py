import tkinter as tk


root = tk.Tk()

# Label
message = tk.Label(root, text="Hello, World!")
message.pack()

# mostrar pantalla
root.mainloop()