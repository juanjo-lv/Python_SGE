lista_original = [3,6,"hola",5]
factor = 2

lista_final = [elem * factor for elem in lista_original]
print(lista_final)

