import math
potencias = [math.pow(2,int(elemento)) for elemento in range(8,-4,-1)]
print(potencias)
