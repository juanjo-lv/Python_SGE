n = 2;
myset = {elemento/n for elemento in range(1,10,1)}
print(myset)